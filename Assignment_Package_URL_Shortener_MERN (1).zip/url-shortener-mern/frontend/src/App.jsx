import React from 'react'
import UrlForm from './components/UrlForm.jsx'
import AdminPage from './components/AdminPage.jsx'
export default function App(){
  const [tab, setTab] = React.useState('home')
  return (
    <div style={{fontFamily:'Inter, Arial',padding:24,maxWidth:900,margin:'0 auto'}}>
      <header style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:16}}>
        <h1>URL Shortener (MERN)</h1>
        <nav>
          <button onClick={()=>setTab('home')} style={{marginRight:8}}>Home</button>
          <button onClick={()=>setTab('admin')}>Admin</button>
        </nav>
      </header>
      {tab==='home'?<UrlForm/>:<AdminPage/>}
    </div>
  )
}