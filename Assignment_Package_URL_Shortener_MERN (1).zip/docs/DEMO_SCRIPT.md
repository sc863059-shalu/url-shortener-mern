# Demo Script (≈1 min)
Open Home → type long URL → Shorten → open short URL (redirect) → Admin shows click count.
