# Deploy
Backend → Render (Node), Frontend → Vercel (Vite). Set env vars:
- MONGODB_URI (Mongo Atlas)
- BASE_URL (Render URL)
