# URL Shortener (MERN)
Features: shorten URL, redirect by /:code, click tracking, admin list.

## Quick Start
### Backend
```
cd url-shortener-mern/backend
cp .env.sample .env
npm install
npm run dev
```
### Frontend
```
cd ../frontend
npm install
npm run dev
```
- Frontend: http://localhost:5173 (proxy to backend http://localhost:3000)
- Set `MONGODB_URI` and `BASE_URL` in `.env`.

## API
- POST /api/shorten
- GET /:code
- GET /api/urls

See DEPLOY.md, SUBMISSION.md, DEMO_SCRIPT.md for more.
