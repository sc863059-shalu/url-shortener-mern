# Submission
Include repo link + optional live URLs.
Demo timestamps (~1 min): 00:00 Home, 00:05 Type, 00:25 Shorten, 00:35 Redirect, 00:50 Admin.
